AI CALM POD — FINAL WEBSITE
Colour palette: warm ivory #F6F3EA, warm beige #E5DDCD, soft charcoal #30372F, beige accent #D5C9B7.

This package contains:
- index.html: complete responsive website with project content, navigation, responsive layout, CSS illustration, and subtle scroll reveal.

Preview:
1. Download and extract the ZIP.
2. Open index.html in a modern browser.

Publish to your existing GitHub Pages site:
1. Go to https://github.com/nainajangir709-cyber/AI-CALM-POD
2. Replace the repository's index.html with this index.html.
3. Commit the change to the branch/folder used by GitHub Pages.
4. Wait for GitHub Pages to deploy.
Your published URL remains https://nainajangir709-cyber.github.io/AI-CALM-POD/

Important: this is a static concept website, not a live AI/sensor implementation. I cannot publish to your GitHub account from this file package.
